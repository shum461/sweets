## ----include = FALSE------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
options(width=250,tibble.print_min=Inf,tibble.width=Inf)

knitr::opts_chunk$set( 
  collapse = TRUE,
  comment = "#>"
)

#devtools::build_rmd("vignettes/dispositions-and-listings.Rmd") 

## ----setup, warning=FALSE-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
library(sweets)
library(dplyr,warn.conflicts = FALSE)


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
data(broken_pk, package = "sweets")

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

broken_pk %>%
  cnt(DELFN,DELFNC,prop = FALSE)

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

broken_pk %>%
  cnt(DVID,DVIDC,prop = FALSE)


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

broken_pk %>%
    group_by(USUBJID) %>%
    filter(any(DELFN==14)) %>%
    select(USUBJID,DTTM,DVID,TSFD,DELFN)


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

broken_pk_samples <- 
  broken_pk %>%
  filter(EVID==0)


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
broken_pk_samples %>%
  cnt(DVID,DVIDC,prop = FALSE)

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

disposition_table <- broken_pk_samples %>%
  sweet_disposition(subjid = USUBJID,group_vars = STUDYID) 

disposition_table %>%
  print(n = 15,width = Inf)



## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

broken_pk_samples %>%
  sweet_disposition(subjid = USUBJID,
                    group_vars = STUDYID,
                    cnt_n_keeps = 50) %>%
  print(n = 15,width = Inf)


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

pooled_disposition <- disposition_table %>%
  pool_disposition() 

pooled_disposition %>%
  print(n = 15, width = Inf)



## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

report_disposition <- disposition_table %>%
  filter(`Flag #`> 7) 

report_disposition %>%
  print(n = 15, width = Inf)


## ----echo=TRUE, eval=FALSE------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 
# disposition_tabs <- list("pooled"= pooled_disposition,
#                          "report"= report_disposition,
#                          "programmer"= disposition_table,
#                          )
# 
# writexl::write_xlsx(disposition_tabs,"disposition.xlsx")
# 

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

attr(disposition_table,"subjects_in_flag") %>%
    filter(DELFN %in% c(50,10)) %>%
    tidyr::unnest(subjects_in_flag)


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

del_report <- build_report(file_name = "pk-deletion-listings")


## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
disposition_table %>%
  filter(`Samples Excluded`>0) %>%
  select(STUDYID,`Flag #`,`Reason for Deletion`,`Samples Excluded`)

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# call the initialized deletion report 
# build listing tables and add them inside add_listing_to_report()
# Add tables to the report

del_report <- del_report %>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT01', DELFN == 7) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(STUDYID,USUBJID,TRT),
    title = "Study 01 Placebo Group Not Included in the Analysis")
  ) %>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT02', DELFN == 7) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(STUDYID,USUBJID,TRT,ACTARM),
    title = "Study 02 Placebo Group Not Included in the Analysis")
  )%>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT01', DELFN == 9) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(USUBJID,DTTM,VISIT,PCTPT,PCTEST,PCSTRESN),
    title = "Study 01 Missing Concentration Value")
  ) %>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT01', DELFN == 10) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(USUBJID,DTTM,VISIT,PCTPT,PCTEST,PCSTRESN),
    title = "Study 01 Missing Sample Date and/or Time")
  ) %>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT02', DELFN == 14) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(USUBJID,DTTM,VISIT,PCTPT,PCTEST,DVIDC,DV),
    title = "Study 02 Missing Sample Date and/or Time")
  )%>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT01', DELFN == 50) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(USUBJID,DTTM,VISIT,PCTPT,PCTEST,DVIDC,DV),
    title = "Study 01 Analyst-Identified Outliers")
  ) %>%
  add_listing_to_report(
    listing_table(
    broken_pk_samples %>% 
    filter(STUDYID=='CDISCPILOT02', DELFN == 50) %>%
    arrange(STUDYID, USUBJID, DTTM) %>%
    select(USUBJID,DTTM,VISIT,PCTPT,PCTEST,DVIDC,DV),
    title = "Study 02 Analyst-Identified Outliers") 
  )

 
  

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
get_listing_info(del_report)

## -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
get_listing_info(del_report,id_var = "none") %>%
  dplyr::slice(7) %>%
  tidyr::unnest(listing)

## ----eval=FALSE-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 
# # Write Listings
# write_listings_report(del_report)
# 

