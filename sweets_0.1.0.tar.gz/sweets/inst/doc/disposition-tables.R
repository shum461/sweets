## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(sweets)
library(dplyr)

## -----------------------------------------------------------------------------

#sweets::sweet_disposition(fd, subjid = USUBJID)


